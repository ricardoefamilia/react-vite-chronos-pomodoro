import { PlayCircleIcon } from 'lucide-react';
import { Cycles } from '../Cycles';
import { DefaultButton } from '../DefaultButton';
import { DefaultInput } from '../DefaultInput';
import styles from './style.module.css';
import { useRef } from 'react';

export function MainForm() {
  // const [taskName, setTaskName] = useState(''); // (input controlado) se quiser renderizar cada contexto durante o preenchimento do formulário.
  const taskNameInput = useRef<HTMLInputElement>(null); // input não controlado

  function handleCreateNewTask(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); // Não envia o formulário.
    console.log('Passou aqui: ' + taskNameInput);
    if (taskNameInput.current === null) return;

    const taskName = taskNameInput.current.value.trim();
    console.log('Passou aqui também: ' + taskName);
    if (!taskName) {
      alert('Digite o nome da tarefa.');
      return;
    }
  }
  return (
    <form onSubmit={handleCreateNewTask} className={styles.form} action=''>
      <div className={styles.formRow}>
        {/* <DefaultInput
          type='text'
          id='meuInput'
          placeHolder='Digite algo...'
          value={taskName}
          onChange={e => setTaskName(e.target.value)}
        /> */}
        <DefaultInput
          type='text'
          id='meuInput'
          placeHolder='Digite algo...'
          ref={taskNameInput}
        />
      </div>

      <div className={styles.formRow}>
        <p>Próximo intervalo é de 25min</p>
      </div>

      <div className={styles.formRow}>
        <Cycles />
      </div>

      <div className={styles.formRow}>
        <DefaultButton icon={<PlayCircleIcon />} color='green' />
        {/* <DefaultButton icon={<StopCircleIcon />} color='red' /> */}
      </div>
    </form>
  );
}
