let isRunning = false;

self.onmessage = function (event) {
  if (isRunning) return;

  isRunning = true;

  const state = event.data;
  const { activeTask, secondsRemaining } = state;

  // calculo para terminar cada ciclo
  const endDate = activeTask.startDate + secondsRemaining * 1000;
  console.log(new Date(endDate));

  const now = Date.now();
  let countDownSeconds = Math.ceil((endDate - now) / 1000);

  // Primeiro segundo
  function tick() {
    self.postMessage(countDownSeconds);

    const now = Date.now();
    countDownSeconds = Math.floor((endDate - now) / 1000);

    setTimeout(tick, 1000);
  }

  tick();
};
