let isRunning = false;

self.onmessage = function (event) {
  if (isRunning) return;

  isRunning = true;

  const state = event.data;
  const { activeTask, seconsRemaining } = state;

  // calculo para terminar cada ciclo
  const endDate = activeTask.startDate + seconsRemaining * 1000;
  console.log(new Date(endDate));

  // Primeiro segundo
};
